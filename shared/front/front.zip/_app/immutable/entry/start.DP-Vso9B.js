import{a as t}from"../chunks/entry.DbKM3Aia.js";export{t as start};
