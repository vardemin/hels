import{w as s}from"./index.B3LP2-NE.js";function c(n){return(n==null?void 0:n.length)!==void 0?n:Array.from(n)}const f=s("");export{f as c,c as e};
